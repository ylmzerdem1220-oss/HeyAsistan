package com.heyasistan.app

import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * "Diğer uygulamaların üzerinde göster" iznine benzer, ama Ayarlar'dan ayrıca
 * açılan özel bir izinle (Bildirim Erişimi) çalışan servis. Açıldığında,
 * WhatsApp, Instagram, e-posta gibi uygulamaların bildirim çubuğunda
 * GÖRÜNEN kısmını (başlık + önizleme metni) hafızada tutar. Uygulamaların
 * kendi şifreli mesaj veritabanına erişim YOKTUR — sadece bildirimde
 * görünen kadarını okuyabiliriz, bu Android'in izin verdiği sınırdır.
 *
 * Veriler sadece cihaz hafızasında (RAM) tutulur, hiçbir yere gönderilmez;
 * uygulama tamamen kapanırsa (sistem tarafından öldürülürse) sıfırlanır.
 */
class NotificationCaptureService : NotificationListenerService() {

    data class CapturedNotification(
        val packageName: String,
        val appLabel: String,
        val title: String,
        val text: String,
        val time: Long
    )

    companion object {
        // packageName -> en son bildirim
        private val latestPerApp = mutableMapOf<String, CapturedNotification>()

        @Synchronized
        fun record(n: CapturedNotification) {
            latestPerApp[n.packageName] = n
        }

        /** Belirtilen uygulama adına (örn. "whatsapp") en yakın son bildirimi bulur. */
        @Synchronized
        fun latestFor(context: Context, appNameRaw: String?): String {
            if (!isAccessGranted(context)) {
                return "Bildirim erişimi izni verilmemiş, bu yüzden göremiyorum."
            }
            val appName = appNameRaw?.lowercase()?.trim()
            if (appName.isNullOrBlank()) {
                val latest = latestPerApp.values.maxByOrNull { it.time }
                    ?: return "Henüz yakaladığım bir bildirim yok."
                return format(latest)
            }
            val match = latestPerApp.values.firstOrNull {
                it.appLabel.lowercase().contains(appName) || appName.contains(it.appLabel.lowercase()) ||
                    it.packageName.lowercase().contains(appName)
            } ?: return "$appName için henüz yakaladığım bir bildirim yok."
            return format(match)
        }

        private fun format(n: CapturedNotification): String {
            val preview = if (n.text.length > 80) n.text.take(80) + "…" else n.text
            return "${n.appLabel} uygulamasından en son: ${n.title} — $preview"
        }

        fun isAccessGranted(context: Context): Boolean {
            val enabled = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
            return enabled?.contains(context.packageName) == true
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            val extras = sbn.notification.extras
            val title = extras.getCharSequence("android.title")?.toString().orEmpty()
            val text = extras.getCharSequence("android.text")?.toString().orEmpty()
            if (title.isBlank() && text.isBlank()) return

            val label = try {
                val pm = packageManager
                pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
            } catch (e: Exception) {
                sbn.packageName
            }

            record(
                CapturedNotification(
                    packageName = sbn.packageName,
                    appLabel = label,
                    title = title,
                    text = text,
                    time = sbn.postTime
                )
            )
        } catch (e: Exception) { }
    }
}
