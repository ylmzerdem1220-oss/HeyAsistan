package com.heyasistan.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var toggleButton: Button
    private var listening = false

    private val requiredPermissions: Array<String>
        get() {
            val perms = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                perms.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            return perms.toTypedArray()
        }

    private val permissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            startAssistant()
        } else {
            Toast.makeText(this, "Mikrofon, rehber ve arama izinleri olmadan çalışamaz", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        toggleButton = findViewById(R.id.toggleButton)

        toggleButton.setOnClickListener {
            if (!listening) {
                if (hasAllPermissions()) startAssistant()
                else permissionLauncher.launch(requiredPermissions)
            } else {
                stopAssistant()
            }
        }

        val apiKeyInput = findViewById<EditText>(R.id.apiKeyInput)
        val saveKeyButton = findViewById<Button>(R.id.saveKeyButton)

        apiKeyInput.setText(ApiKeyStore.get(this) ?: "")
        saveKeyButton.setOnClickListener {
            val key = apiKeyInput.text.toString().trim()
            ApiKeyStore.save(this, key)
            val msg = if (key.isBlank()) "Anahtar temizlendi — kelime tabanlı sisteme dönüldü"
                      else "Gemini anahtarı kaydedildi"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }

        val overlayPermButton = findViewById<Button>(R.id.overlayPermButton)
        updateOverlayButtonLabel(overlayPermButton)
        overlayPermButton.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "İzin zaten verilmiş", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        findViewById<Button>(R.id.overlayPermButton)?.let { updateOverlayButtonLabel(it) }
    }

    private fun updateOverlayButtonLabel(button: Button) {
        val granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)
        button.text = if (granted) "İzin Verildi ✓" else "Bu İzni Ver"
    }

    private fun hasAllPermissions(): Boolean =
        requiredPermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    private fun startAssistant() {
        val intent = Intent(this, VoiceAssistantService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
        listening = true
        statusText.text = "Dinliyor — \"Hey\" bekleniyor"
        toggleButton.text = "Durdur"
    }

    private fun stopAssistant() {
        val intent = Intent(this, VoiceAssistantService::class.java).setAction(VoiceAssistantService.ACTION_STOP)
        startService(intent)
        listening = false
        statusText.text = "Durduruldu"
        toggleButton.text = "Dinlemeyi Başlat"
    }
}
