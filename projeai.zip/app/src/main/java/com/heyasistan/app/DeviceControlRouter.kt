package com.heyasistan.app

import android.app.AlarmManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.session.MediaSessionManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings

/**
 * Fener, ses, parlaklık, müzik oynatma, SMS gönderme, alarm/zamanlayıcı gibi
 * telefonun donanım/sistem kontrollerini sesli komutla yöneten modül.
 */
object DeviceControlRouter {

    fun handle(context: Context, controlKind: String?, query: String?, contactName: String?): String {
        return when (controlKind) {
            "flashlight_on" -> setFlashlight(context, true)
            "flashlight_off" -> setFlashlight(context, false)
            "volume_up" -> adjustVolume(context, AudioManager.ADJUST_RAISE)
            "volume_down" -> adjustVolume(context, AudioManager.ADJUST_LOWER)
            "mute" -> adjustVolume(context, AudioManager.ADJUST_MUTE)
            "brightness_up" -> adjustBrightness(context, 40)
            "brightness_down" -> adjustBrightness(context, -40)
            "play_media" -> mediaControl(context, "play")
            "pause_media" -> mediaControl(context, "pause")
            "next_media" -> mediaControl(context, "next")
            "previous_media" -> mediaControl(context, "previous")
            "whats_playing" -> whatsPlaying(context)
            "set_alarm" -> setAlarm(context, query)
            "set_timer" -> setTimer(context, query)
            "open_wifi_settings" -> openSettings(context, Settings.ACTION_WIFI_SETTINGS, "Wi-Fi ayarlarını açtım.")
            "open_bluetooth_settings" -> openSettings(context, Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth ayarlarını açtım.")
            // send_sms / send_whatsapp burada YOK: bu ikisi VoiceAssistantService
            // tarafından önce ONAY sorularak, sonra buildConfirmationQuestion /
            // executeSendAction üzerinden ayrıca yönetiliyor.
            else -> "Bu komutu nasıl uygulayacağımı anlayamadım."
        }
    }

    /** Gönderim öncesi kullanıcıya sorulacak onay cümlesini üretir. */
    fun buildConfirmationQuestion(contactName: String?, message: String?): String {
        val name = contactName?.takeIf { it.isNotBlank() } ?: "bu kişiye"
        val text = message?.takeIf { it.isNotBlank() } ?: "bu mesajı"
        return "$name WhatsApp'tan \"$text\" mesajını göndereyim mi? Onaylamak için evet, vazgeçmek için hayır de."
    }

    /** Kullanıcı "evet" dedikten SONRA WhatsApp'ı mesaj hazır halde açar. */
    fun executeSendAction(context: Context, contactName: String?, message: String?): String =
        sendWhatsapp(context, contactName, message)

    // ---------------- Fener ----------------

    private fun setFlashlight(context: Context, on: Boolean): String {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val camId = cm.cameraIdList.firstOrNull() ?: return "Bu cihazda fener bulamadım."
            cm.setTorchMode(camId, on)
            if (on) "Feneri açtım." else "Feneri kapattım."
        } catch (e: Exception) {
            "Feneri kontrol edemedim, bu cihazda desteklenmiyor olabilir."
        }
    }

    // ---------------- Ses ----------------

    private fun adjustVolume(context: Context, direction: Int): String {
        return try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
            when (direction) {
                AudioManager.ADJUST_RAISE -> "Sesi açtım."
                AudioManager.ADJUST_LOWER -> "Sesi kıstım."
                else -> "Sesi kapattım."
            }
        } catch (e: Exception) {
            "Sesi ayarlayamadım."
        }
    }

    // ---------------- Parlaklık ----------------

    private fun adjustBrightness(context: Context, delta: Int): String {
        if (!Settings.System.canWrite(context)) {
            return "Parlaklık izni verilmemiş. Ayarlardan \"Sistem ayarlarını değiştir\" iznini vermen gerekiyor."
        }
        return try {
            val current = Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
            val next = (current + delta).coerceIn(10, 255)
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, next)
            if (delta > 0) "Ekranı parlattım." else "Ekranı kıstım."
        } catch (e: Exception) {
            "Parlaklığı ayarlayamadım."
        }
    }

    // ---------------- Müzik kontrolü ----------------
    // NOT: Bu özellik, "Bildirim Erişimi" izni verildiyse çalışır — müzik
    // oturumlarına erişim, Android'de bildirim dinleme izniyle birlikte gelir.

    private fun activeMediaController(context: Context) = try {
        val msm = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        val component = ComponentName(context, NotificationCaptureService::class.java)
        msm.getActiveSessions(component).firstOrNull()
    } catch (e: SecurityException) {
        null
    } catch (e: Exception) {
        null
    }

    private fun mediaControl(context: Context, action: String): String {
        val controller = activeMediaController(context)
            ?: return "Şu an kontrol edebileceğim bir müzik oturumu bulamadım. Bildirim Erişimi izni verilmiş mi kontrol et."
        return try {
            when (action) {
                "play" -> { controller.transportControls.play(); "Çalıyorum." }
                "pause" -> { controller.transportControls.pause(); "Durdurdum." }
                "next" -> { controller.transportControls.skipToNext(); "Sonraki şarkıya geçtim." }
                "previous" -> { controller.transportControls.skipToPrevious(); "Önceki şarkıya döndüm." }
                else -> "Anlaşılamadı."
            }
        } catch (e: Exception) {
            "Müziği kontrol edemedim."
        }
    }

    private fun whatsPlaying(context: Context): String {
        val controller = activeMediaController(context)
            ?: return "Şu an çalan bir şey göremiyorum, ya da Bildirim Erişimi izni verilmemiş."
        val metadata = controller.metadata ?: return "Şu an ne çaldığını göremiyorum."
        val title = metadata.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)
        val artist = metadata.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST)
        return if (title != null) "Şu an çalan: $title${if (artist != null) " - $artist" else ""}."
        else "Şu an ne çaldığını göremiyorum."
    }

    // ---------------- WhatsApp gönderme ----------------
    // ÖNEMLİ SINIR: WhatsApp, hiçbir uygulamanın onun adına sessizce "gönder"
    // tuşuna basmasına izin vermez (spam'i önlemek için kasıtlı bir kısıtlama).
    // Yapabildiğimiz en fazlası: WhatsApp'ı, mesaj kutusu dolu halde, doğru
    // kişinin sohbetinde açmak — son "gönder" dokunuşu kullanıcıya kalıyor.
    private fun sendWhatsapp(context: Context, contactNameRaw: String?, message: String?): String {
        val contactName = contactNameRaw?.trim()
        if (contactName.isNullOrBlank()) return "Kime göndereceğimi anlayamadım."
        if (message.isNullOrBlank()) return "Ne yazacağımı anlayamadım."

        val number = lookupContactNumber(context, contactName)
            ?: return "$contactName rehberde bulunamadı."

        // wa.me linki tam uluslararası formatta numara ister (başında + ya da 0 olmadan).
        // Rehberdeki numara yerel formatta (05xx...) kayıtlıysa, Türkiye kodu (90)
        // otomatik eklenmeye çalışılıyor — ama numaranın rehberde doğru/uluslararası
        // formatta kayıtlı olması en sağlıklısı.
        var cleanNumber = number.replace(Regex("[^0-9]"), "")
        if (cleanNumber.startsWith("0")) cleanNumber = "90" + cleanNumber.substring(1)
        else if (!cleanNumber.startsWith("90") && cleanNumber.length <= 10) cleanNumber = "90$cleanNumber"

        return try {
            val uri = Uri.parse("https://wa.me/$cleanNumber?text=" + Uri.encode(message))
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "$contactName ile WhatsApp sohbetini mesaj hazır halde açtım, göndermek için sadece gönder tuşuna basman gerekiyor."
        } catch (e: Exception) {
            "WhatsApp'ı açamadım, yüklü olmayabilir."
        }
    }

    private fun lookupContactNumber(context: Context, name: String): String? {
        val uri = android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIdx = cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (cursor.moveToNext()) {
                val n = cursor.getString(nameIdx)?.lowercase() ?: continue
                if (n.contains(name.lowercase()) || name.lowercase().contains(n)) {
                    return cursor.getString(numberIdx)
                }
            }
        }
        return null
    }

    // ---------------- Alarm / Zamanlayıcı ----------------

    private fun setAlarm(context: Context, timeQuery: String?): String {
        val match = Regex("(\\d{1,2}):(\\d{2})").find(timeQuery ?: "")
            ?: return "Saati anlayamadım, örn. \"7:30'a alarm kur\" gibi söyle."
        val hour = match.groupValues[1].toIntOrNull() ?: return "Saati anlayamadım."
        val minute = match.groupValues[2].toIntOrNull() ?: return "Saati anlayamadım."

        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            "%02d:%02d için alarm kurdum.".format(hour, minute)
        } catch (e: Exception) {
            "Alarm kuramadım."
        }
    }

    private fun setTimer(context: Context, minutesQuery: String?): String {
        val minutes = Regex("\\d+").find(minutesQuery ?: "")?.value?.toIntOrNull()
            ?: return "Kaç dakika olduğunu anlayamadım."
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, minutes * 60)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            "$minutes dakikalık zamanlayıcı kurdum."
        } catch (e: Exception) {
            "Zamanlayıcı kuramadım."
        }
    }

    // ---------------- Ayarlar ekranları ----------------

    private fun openSettings(context: Context, action: String, successMessage: String): String {
        return try {
            context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            successMessage
        } catch (e: Exception) {
            "Ayarları açamadım."
        }
    }
}
