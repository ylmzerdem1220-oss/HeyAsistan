package com.heyasistan.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract

/**
 * Söylenen metni yorumlayıp gerçek bir eylem (uygulama açma, uygulama içi arama,
 * Google'da arama, kişi arama) üreten sınıf. Artık kalıp/sıra şartı aramaz:
 * "google ronaldonun yaşı", "hey youtube'de orkun ışıtmak aç" gibi doğal
 * cümleleri de anlar — kelime cümlenin neresinde geçerse geçsin çalışır.
 */
object CommandRouter {

    sealed class Result {
        data class OpenedApp(val label: String) : Result()
        data class OpenedAppSearch(val label: String, val query: String) : Result()
        data class OpenedSearch(val query: String) : Result()
        data class Calling(val name: String, val number: String) : Result()
        data class ContactNotFound(val name: String) : Result()
        object NotUnderstood : Result()
    }

    private val APP_ALIASES = mapOf(
        "youtube" to "com.google.android.youtube",
        "instagram" to "com.instagram.android",
        "whatsapp" to "com.whatsapp",
        "twitter" to "com.twitter.android",
        "spotify" to "com.spotify.music",
        "gmail" to "com.google.android.gm",
        "netflix" to "com.netflix.mediaclient",
        "harita" to "com.google.android.apps.maps",
        "chrome" to "com.android.chrome",
        "ayarlar" to "com.android.settings",
        "kamera" to "com.android.camera",
        "galeri" to "com.google.android.apps.photos",
        "telegram" to "org.telegram.messenger",
        "tiktok" to "com.zhiliaoapp.musically"
    )

    // Komut anlamı taşımayan, çıkarılıp atılacak "dolgu" kelimeler.
    private val FILLER_WORDS = setOf(
        "aç", "ara", "arasana", "bulsana", "bul", "göster", "gir", "girsene",
        "bana", "şunu", "şu", "bir", "lütfen", "hemen", "de", "da", "den", "dan",
        "içinde", "icinde", "üzerinden", "uzerinden"
    )

    fun normalize(s: String): String =
        s.lowercase()
            .replace("İ", "i").replace("I", "ı")
            .replace(Regex("['’]"), "")
            .trim()

    /** Metinden verilen kök kelimeyle başlayan tüm kelimeleri siler (örn. "youtube\\w*" -> "youtubede" de silinir). */
    private fun stripWord(text: String, root: String): String =
        text.replace(Regex("\\b$root\\w*"), " ")

    /** Kalan metindeki dolgu kelimeleri atıp gerçek arama sorgusunu çıkarır. */
    private fun extractQuery(text: String): String {
        val words = text.split(Regex("\\s+")).filter { it.isNotBlank() && it !in FILLER_WORDS }
        return words.joinToString(" ").trim()
    }

    /**
     * "hey" ten sonra söylenen komutu işler ve uygun eylemi çalıştırır.
     */
    fun handle(context: Context, rawText: String): Result {
        val text = normalize(rawText)

        // 1) Google araması: cümlede "google" geçiyorsa, kalan her şey sorgudur.
        //    Sıra ve "ara" kelimesi şart değil: "google ronaldonun yaşı" da çalışır.
        if (Regex("\\bgoogle\\w*").containsMatchIn(text)) {
            val remainder = stripWord(text, "google")
            val query = extractQuery(remainder)
            if (query.isNotBlank()) {
                val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
                val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return Result.OpenedSearch(query)
            }
        }

        // 2) Bilinen uygulamalar: "X aç" / "X'de Y aç" / "X'te Y ara"
        //    Uygulama adı geçen kelime cümlenin neresinde olursa olsun tanınır;
        //    kalan kelimeler varsa uygulama içi arama olarak kullanılır.
        for ((alias, pkg) in APP_ALIASES) {
            if (Regex("\\b$alias\\w*").containsMatchIn(text)) {
                val remainder = stripWord(text, alias)
                val query = extractQuery(remainder)

                if (query.isNotBlank()) {
                    if (openAppWithSearch(context, alias, pkg, query)) {
                        return Result.OpenedAppSearch(alias, query)
                    }
                }
                // sorgu yoksa (veya uygulama içi arama desteklenmiyorsa) sadece uygulamayı aç
                if (launchByPackage(context, pkg)) return Result.OpenedApp(alias)
                if (launchByLabel(context, alias)) return Result.OpenedApp(alias)
                return Result.NotUnderstood
            }
        }

        // 3) Kişi arama: cümlede "ara" geçiyorsa ve bilinen bir uygulama adı yoksa,
        //    kalan kelimeler kişi ismi olarak değerlendirilir.
        if (Regex("\\bara\\w*").containsMatchIn(text)) {
            val remainder = stripWord(text, "ara")
            val name = extractQuery(remainder)
            if (name.isNotBlank()) {
                val number = lookupContactNumber(context, name)
                if (number != null) {
                    val call = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(call)
                    return Result.Calling(name, number)
                }
                return Result.ContactNotFound(name)
            }
        }

        // 4) Bilinmeyen ama "aç" içeren komut: yüklü uygulamalar arasında isimle eşleştirmeyi dene
        if (Regex("\\baç\\w*").containsMatchIn(text)) {
            val remainder = stripWord(text, "aç")
            val appGuess = extractQuery(remainder)
            if (appGuess.isNotBlank() && launchByLabel(context, appGuess)) {
                return Result.OpenedApp(appGuess)
            }
        }

        return Result.NotUnderstood
    }

    // ---------------------------------------------------------------
    // Aşağıdaki fonksiyonlar, Gemini AI'nin yorumladığı yapılandırılmış
    // sonucu (GeminiRouter.ParsedAction) gerçek bir eyleme çevirmek için
    // dışarıdan da çağrılabilir hale getirilmiştir.
    // ---------------------------------------------------------------

    fun runGoogleSearch(context: Context, queryRaw: String?): Result {
        val q = queryRaw?.trim().orEmpty()
        if (q.isBlank()) return Result.NotUnderstood
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))
        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return Result.OpenedSearch(q)
    }

    fun runAppOpen(context: Context, appNameRaw: String?): Result {
        val appName = normalize(appNameRaw ?: "").trim()
        if (appName.isBlank()) return Result.NotUnderstood
        val pkg = APP_ALIASES[appName]
        if (pkg != null && launchByPackage(context, pkg)) return Result.OpenedApp(appName)
        if (launchByLabel(context, appName)) return Result.OpenedApp(appName)
        return Result.NotUnderstood
    }

    fun runAppSearch(context: Context, appNameRaw: String?, queryRaw: String?): Result {
        val appName = normalize(appNameRaw ?: "").trim()
        val q = queryRaw?.trim().orEmpty()
        if (appName.isBlank()) return runGoogleSearch(context, q)
        val pkg = APP_ALIASES[appName]
        if (pkg != null) {
            if (q.isNotBlank() && openAppWithSearch(context, appName, pkg, q)) {
                return Result.OpenedAppSearch(appName, q)
            }
            if (launchByPackage(context, pkg)) return Result.OpenedApp(appName)
        }
        if (launchByLabel(context, appName)) return Result.OpenedApp(appName)
        return Result.NotUnderstood
    }

    fun runCall(context: Context, nameRaw: String?): Result {
        val name = normalize(nameRaw ?: "").trim()
        if (name.isBlank()) return Result.NotUnderstood
        val number = lookupContactNumber(context, name)
        return if (number != null) {
            val call = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(call)
            Result.Calling(name, number)
        } else {
            Result.ContactNotFound(name)
        }
    }

    /**
     * Bilinen bazı uygulamalar için doğrudan uygulama içi arama sonucunu açar
     * (örn. YouTube'da aratılan şeyi doğrudan arama sonuçlarıyla açar).
     * Desteklenmeyen uygulamalarda false döner, çağıran taraf sade açmaya düşer.
     */
    private fun openAppWithSearch(context: Context, alias: String, pkg: String, query: String): Boolean {
        val pm = context.packageManager
        val installed = pm.getLaunchIntentForPackage(pkg) != null
        if (!installed) return false

        val uri: Uri? = when (alias) {
            "youtube" -> Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))
            "spotify" -> Uri.parse("https://open.spotify.com/search/" + Uri.encode(query))
            "instagram" -> Uri.parse("https://www.instagram.com/explore/search/keyword/?q=" + Uri.encode(query))
            "twitter" -> Uri.parse("https://twitter.com/search?q=" + Uri.encode(query))
            "netflix" -> Uri.parse("https://www.netflix.com/search?q=" + Uri.encode(query))
            "harita" -> Uri.parse("geo:0,0?q=" + Uri.encode(query))
            "chrome" -> Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
            else -> null
        } ?: return false

        val intent = Intent(Intent.ACTION_VIEW, uri)
            .setPackage(pkg)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun launchByPackage(context: Context, packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    /** Paket adını bilmediğimiz uygulamaları görünen isimlerinden bulup açar. */
    private fun launchByLabel(context: Context, spokenName: String): Boolean {
        val pm = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcherIntent, 0)
        val target = apps.firstOrNull { info ->
            val label = info.loadLabel(pm).toString().lowercase()
            label.contains(spokenName) || spokenName.contains(label)
        } ?: return false

        val launch = pm.getLaunchIntentForPackage(target.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return true
    }

    /** READ_CONTACTS izniyle rehberden isme göre en YAKIN eşleşen kişiyi bulur.
     *  Basit "contains" yerine benzerlik skoru kullanır; ses tanıma bir harfi
     *  yanlış duysa bile doğru kişiyi bulma ihtimali artar, alakasız bir isme
     *  yanlışlıkla eşleşme ihtimali ise azalır. */
    private fun lookupContactNumber(context: Context, spokenName: String): String? {
        val resolver = context.contentResolver
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )

        var bestNumber: String? = null
        var bestScore = Double.MAX_VALUE

        resolver.query(uri, projection, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (cursor.moveToNext()) {
                val fullName = cursor.getString(nameIdx)?.lowercase() ?: continue
                // Rehberdeki ismin her kelimesini ayrı ayrı dene (soyadı farkı vs. etkilemesin)
                val candidates = fullName.split(Regex("\\s+")) + listOf(fullName)
                for (candidate in candidates) {
                    if (candidate.isBlank()) continue
                    val score = similarityDistance(spokenName, candidate)
                    val maxLen = maxOf(spokenName.length, candidate.length).coerceAtLeast(1)
                    val ratio = score.toDouble() / maxLen
                    // Türkçe ekler yüzünden tam içerme de güçlü bir sinyal — direkt kabul et
                    val containsMatch = candidate.contains(spokenName) || spokenName.contains(candidate)
                    val effectiveRatio = if (containsMatch) 0.0 else ratio
                    if (effectiveRatio < bestScore) {
                        bestScore = effectiveRatio
                        bestNumber = cursor.getString(numberIdx)
                    }
                }
            }
        }

        // Yeterince benzemiyorsa (muhtemelen ses tanıma yanlış duydu ya da rehberde yok)
        // rastgele/yanlış birini aramaktansa "bulunamadı" de.
        return if (bestScore <= 0.4) bestNumber else null
    }

    /** İki kelime arasındaki Levenshtein (düzenleme) mesafesi. */
    private fun similarityDistance(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                dp[i][j] = if (a[i - 1] == b[j - 1]) {
                    dp[i - 1][j - 1]
                } else {
                    1 + minOf(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1])
                }
            }
        }
        return dp[a.length][b.length]
    }
}
