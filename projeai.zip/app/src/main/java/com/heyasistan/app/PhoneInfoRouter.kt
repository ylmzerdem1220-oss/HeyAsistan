package com.heyasistan.app

import android.content.Context
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony

/**
 * "En son kime mesaj attım", "en son kimle konuştum", "kaç dakika konuştum",
 * "gelen kod ne" gibi soruları, telefonun kendi SMS ve arama geçmişi
 * verisinden (kullanıcının açıkça verdiği READ_SMS / READ_CALL_LOG izniyle)
 * cevaplayan modül. Hiçbir veri dışarıya (internete) gönderilmez, sadece
 * cihaz üzerinde okunur.
 */
object PhoneInfoRouter {

    /** info_kind değerine göre uygun cevabı üretir. */
    fun answer(context: Context, infoKind: String?, contactName: String?): String {
        return when (infoKind) {
            "last_sms_code" -> lastVerificationCode(context)
            "last_sent_message" -> lastSentMessage(context)
            "last_received_message" -> lastReceivedMessage(context)
            "last_call" -> lastCall(context)
            "call_duration" -> callDuration(context, contactName)
            else -> "Bu bilgiyi nasıl bulacağımı anlayamadım."
        }
    }

    // ---------------- SMS ----------------

    private fun lastVerificationCode(context: Context): String {
        if (!hasPermission(context, "android.permission.READ_SMS")) {
            return "SMS okuma izni verilmemiş, bu yüzden gelen kodu göremiyorum."
        }
        val uri = Telephony.Sms.Inbox.CONTENT_URI
        val projection = arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE)
        val sort = "${Telephony.Sms.DATE} DESC LIMIT 25"

        context.contentResolver.query(uri, projection, null, null, sort)?.use { cursor ->
            val bodyIdx = cursor.getColumnIndex(Telephony.Sms.BODY)
            val addrIdx = cursor.getColumnIndex(Telephony.Sms.ADDRESS)
            val codeRegex = Regex("\\b\\d{4,8}\\b")
            while (cursor.moveToNext()) {
                val body = cursor.getString(bodyIdx) ?: continue
                val match = codeRegex.find(body) ?: continue
                val sender = cursor.getString(addrIdx) ?: "bilinmeyen numara"
                return "$sender numarasından gelen son kod: ${match.value}"
            }
        }
        return "Son mesajlarda bir doğrulama kodu bulamadım."
    }

    private fun lastSentMessage(context: Context): String {
        if (!hasPermission(context, "android.permission.READ_SMS")) {
            return "SMS okuma izni verilmemiş, bu yüzden mesaj geçmişini göremiyorum."
        }
        val uri = Telephony.Sms.Sent.CONTENT_URI
        val projection = arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY)
        val sort = "${Telephony.Sms.DATE} DESC LIMIT 1"

        context.contentResolver.query(uri, projection, null, null, sort)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val addrIdx = cursor.getColumnIndex(Telephony.Sms.ADDRESS)
                val bodyIdx = cursor.getColumnIndex(Telephony.Sms.BODY)
                val number = cursor.getString(addrIdx) ?: "bilinmeyen numara"
                val name = resolveContactName(context, number) ?: number
                val body = cursor.getString(bodyIdx).orEmpty()
                val preview = if (body.length > 60) body.take(60) + "…" else body
                return "En son $name kişisine şunu yazmışsın: \"$preview\""
            }
        }
        return "Gönderilmiş bir mesaj bulamadım."
    }

    private fun lastReceivedMessage(context: Context): String {
        if (!hasPermission(context, "android.permission.READ_SMS")) {
            return "SMS okuma izni verilmemiş, bu yüzden mesaj geçmişini göremiyorum."
        }
        val uri = Telephony.Sms.Inbox.CONTENT_URI
        val projection = arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY)
        val sort = "${Telephony.Sms.DATE} DESC LIMIT 1"

        context.contentResolver.query(uri, projection, null, null, sort)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val addrIdx = cursor.getColumnIndex(Telephony.Sms.ADDRESS)
                val bodyIdx = cursor.getColumnIndex(Telephony.Sms.BODY)
                val number = cursor.getString(addrIdx) ?: "bilinmeyen numara"
                val name = resolveContactName(context, number) ?: number
                val body = cursor.getString(bodyIdx).orEmpty()
                val preview = if (body.length > 60) body.take(60) + "…" else body
                return "En son $name kişisinden şu mesaj gelmiş: \"$preview\""
            }
        }
        return "Gelen kutusunda mesaj bulamadım."
    }

    // ---------------- Arama geçmişi ----------------

    private fun lastCall(context: Context): String {
        if (!hasPermission(context, "android.permission.READ_CALL_LOG")) {
            return "Arama geçmişi izni verilmemiş, bu yüzden göremiyorum."
        }
        val uri = CallLog.Calls.CONTENT_URI
        val projection = arrayOf(
            CallLog.Calls.CACHED_NAME, CallLog.Calls.NUMBER,
            CallLog.Calls.DURATION, CallLog.Calls.TYPE
        )
        val sort = "${CallLog.Calls.DATE} DESC LIMIT 1"

        context.contentResolver.query(uri, projection, null, null, sort)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIdx = cursor.getColumnIndex(CallLog.Calls.CACHED_NAME)
                val numberIdx = cursor.getColumnIndex(CallLog.Calls.NUMBER)
                val durationIdx = cursor.getColumnIndex(CallLog.Calls.DURATION)
                val typeIdx = cursor.getColumnIndex(CallLog.Calls.TYPE)

                val number = cursor.getString(numberIdx) ?: "bilinmeyen numara"
                val cachedName = cursor.getString(nameIdx)
                val name = cachedName ?: resolveContactName(context, number) ?: number
                val durationSec = cursor.getInt(durationIdx)
                val type = cursor.getInt(typeIdx)

                val typeText = when (type) {
                    CallLog.Calls.MISSED_TYPE -> "cevapsız arama"
                    CallLog.Calls.INCOMING_TYPE -> "gelen arama"
                    CallLog.Calls.OUTGOING_TYPE -> "giden arama"
                    else -> "arama"
                }
                return if (type == CallLog.Calls.MISSED_TYPE) {
                    "En son $name kişisinden bir cevapsız arama var."
                } else {
                    "En son $name ile ${formatDuration(durationSec)} konuşmuşsun ($typeText)."
                }
            }
        }
        return "Arama geçmişinde kayıt bulamadım."
    }

    private fun callDuration(context: Context, contactNameRaw: String?): String {
        if (!hasPermission(context, "android.permission.READ_CALL_LOG")) {
            return "Arama geçmişi izni verilmemiş, bu yüzden göremiyorum."
        }
        val contactName = contactNameRaw?.trim()

        if (contactName.isNullOrBlank()) {
            // Belirli bir isim söylenmediyse en son aramanın süresini ver.
            val uri = CallLog.Calls.CONTENT_URI
            val projection = arrayOf(CallLog.Calls.CACHED_NAME, CallLog.Calls.NUMBER, CallLog.Calls.DURATION)
            val sort = "${CallLog.Calls.DATE} DESC LIMIT 1"
            context.contentResolver.query(uri, projection, null, null, sort)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(CallLog.Calls.CACHED_NAME)
                    val numberIdx = cursor.getColumnIndex(CallLog.Calls.NUMBER)
                    val durationIdx = cursor.getColumnIndex(CallLog.Calls.DURATION)
                    val number = cursor.getString(numberIdx) ?: "bilinmeyen numara"
                    val name = cursor.getString(nameIdx) ?: resolveContactName(context, number) ?: number
                    val durationSec = cursor.getInt(durationIdx)
                    return "En son $name ile ${formatDuration(durationSec)} konuşmuşsun."
                }
            }
            return "Arama geçmişinde kayıt bulamadım."
        }

        // Belirli bir kişi söylendiyse, o kişiyle en son yapılan aramanın süresini bul.
        val uri = CallLog.Calls.CONTENT_URI
        val projection = arrayOf(CallLog.Calls.CACHED_NAME, CallLog.Calls.NUMBER, CallLog.Calls.DURATION)
        val sort = "${CallLog.Calls.DATE} DESC LIMIT 100"
        context.contentResolver.query(uri, projection, null, null, sort)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(CallLog.Calls.CACHED_NAME)
            val numberIdx = cursor.getColumnIndex(CallLog.Calls.NUMBER)
            val durationIdx = cursor.getColumnIndex(CallLog.Calls.DURATION)
            while (cursor.moveToNext()) {
                val cachedName = cursor.getString(nameIdx)?.lowercase()
                val number = cursor.getString(numberIdx) ?: continue
                val resolvedName = cachedName ?: resolveContactName(context, number)?.lowercase()
                if (resolvedName != null &&
                    (resolvedName.contains(contactName.lowercase()) || contactName.lowercase().contains(resolvedName))
                ) {
                    val durationSec = cursor.getInt(durationIdx)
                    return "En son $contactName ile ${formatDuration(durationSec)} konuşmuşsun."
                }
            }
        }
        return "$contactName ile yapılmış bir arama bulamadım."
    }

    // ---------------- Yardımcılar ----------------

    private fun formatDuration(totalSeconds: Int): String {
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return when {
            minutes <= 0 -> "$seconds saniye"
            seconds == 0 -> "$minutes dakika"
            else -> "$minutes dakika $seconds saniye"
        }
    }

    private fun resolveContactName(context: Context, phoneNumber: String): String? {
        if (!hasPermission(context, "android.permission.READ_CONTACTS")) return null
        val uri = android.net.Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            android.net.Uri.encode(phoneNumber)
        )
        context.contentResolver.query(
            uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME)
                return cursor.getString(idx)
            }
        }
        return null
    }

    private fun hasPermission(context: Context, permission: String): Boolean =
        androidx.core.content.ContextCompat.checkSelfPermission(context, permission) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
}
