package com.heyasistan.app

import android.app.AlarmManager
import android.content.Context
import android.location.Geocoder
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.CalendarContract
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

/**
 * Telefonun genel durumunu (pil, internet, depolama, takvim, konum, son
 * fotoğraf, alarm) okuyup sesli cevaba çeviren modül. Hepsi cihaz üzerinde,
 * kullanıcının açıkça verdiği izinlerle çalışır.
 */
object DeviceInfoRouter {

    fun answer(context: Context, infoKind: String?, appNameForNotif: String? = null): String {
        return when (infoKind) {
            "battery_status" -> batteryStatus(context)
            "connectivity_status" -> connectivityStatus(context)
            "storage_status" -> storageStatus(context)
            "installed_apps_count" -> installedAppsCount(context)
            "next_alarm" -> nextAlarm(context)
            "calendar_today" -> calendarEvents(context, daysAhead = 0)
            "calendar_tomorrow" -> calendarEvents(context, daysAhead = 1)
            "calendar_next" -> nextCalendarEvent(context)
            "current_location" -> currentLocation(context)
            "last_photo" -> lastPhoto(context)
            "app_notification" -> NotificationCaptureService.latestFor(context, appNameForNotif)
            else -> "Bu bilgiyi nasıl bulacağımı anlayamadım."
        }
    }

    // ---------------- Pil ----------------

    private fun batteryStatus(context: Context): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return if (charging) "Pil yüzde $level, şu an şarj oluyor."
        else "Pil yüzde $level."
    }

    // ---------------- Bağlantı ----------------

    private fun connectivityStatus(context: Context): String {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return "İnternete bağlı değilsin."
        val caps = cm.getNetworkCapabilities(network) ?: return "İnternete bağlı değilsin."
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi'a bağlısın, internet çalışıyor."
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobil veri ile bağlısın, internet çalışıyor."
            else -> "İnternete bağlısın."
        }
    }

    // ---------------- Depolama ----------------

    private fun storageStatus(context: Context): String {
        val stat = StatFs(Environment.getDataDirectory().path)
        val totalGb = stat.totalBytes / (1024.0 * 1024.0 * 1024.0)
        val freeGb = stat.availableBytes / (1024.0 * 1024.0 * 1024.0)
        return "Toplam %.1f GB depolamanın %.1f GB'ı boş.".format(totalGb, freeGb)
    }

    // ---------------- Yüklü uygulama sayısı ----------------

    private fun installedAppsCount(context: Context): String {
        val pm = context.packageManager
        val launcherIntent = android.content.Intent(android.content.Intent.ACTION_MAIN)
            .addCategory(android.content.Intent.CATEGORY_LAUNCHER)
        val count = pm.queryIntentActivities(launcherIntent, 0).size
        return "Telefonunda yaklaşık $count uygulama yüklü."
    }

    // ---------------- Alarm ----------------

    private fun nextAlarm(context: Context): String {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val next = am.nextAlarmClock ?: return "Kurulu bir alarm göremiyorum."
        val fmt = SimpleDateFormat("d MMMM, HH:mm", Locale("tr"))
        return "Sıradaki alarmın: ${fmt.format(Date(next.triggerTime))}."
    }

    // ---------------- Takvim ----------------

    private fun calendarEvents(context: Context, daysAhead: Int): String {
        if (!hasPermission(context, android.Manifest.permission.READ_CALENDAR)) {
            return "Takvim izni verilmemiş, bu yüzden göremiyorum."
        }
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, daysAhead)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val start = cal.timeInMillis
        cal.add(Calendar.DAY_OF_YEAR, 1)
        val end = cal.timeInMillis

        val uri = CalendarContract.Events.CONTENT_URI
        val projection = arrayOf(CalendarContract.Events.TITLE, CalendarContract.Events.DTSTART)
        val selection = "${CalendarContract.Events.DTSTART} >= ? AND ${CalendarContract.Events.DTSTART} < ?"
        val args = arrayOf(start.toString(), end.toString())

        val titles = mutableListOf<String>()
        context.contentResolver.query(uri, projection, selection, args, "${CalendarContract.Events.DTSTART} ASC")?.use { cursor ->
            val titleIdx = cursor.getColumnIndex(CalendarContract.Events.TITLE)
            while (cursor.moveToNext()) {
                cursor.getString(titleIdx)?.let { titles.add(it) }
            }
        }
        val gun = if (daysAhead == 0) "bugün" else "yarın"
        return if (titles.isEmpty()) "$gun takviminde bir şey görünmüyor."
        else "$gun takviminde: ${titles.joinToString(", ")}."
    }

    private fun nextCalendarEvent(context: Context): String {
        if (!hasPermission(context, android.Manifest.permission.READ_CALENDAR)) {
            return "Takvim izni verilmemiş, bu yüzden göremiyorum."
        }
        val now = System.currentTimeMillis()
        val uri = CalendarContract.Events.CONTENT_URI
        val projection = arrayOf(CalendarContract.Events.TITLE, CalendarContract.Events.DTSTART)
        val selection = "${CalendarContract.Events.DTSTART} >= ?"
        val args = arrayOf(now.toString())

        context.contentResolver.query(uri, projection, selection, args, "${CalendarContract.Events.DTSTART} ASC LIMIT 1")?.use { cursor ->
            if (cursor.moveToFirst()) {
                val titleIdx = cursor.getColumnIndex(CalendarContract.Events.TITLE)
                val startIdx = cursor.getColumnIndex(CalendarContract.Events.DTSTART)
                val title = cursor.getString(titleIdx) ?: "isimsiz etkinlik"
                val time = cursor.getLong(startIdx)
                val fmt = SimpleDateFormat("d MMMM, HH:mm", Locale("tr"))
                return "Sıradaki etkinliğin: $title, ${fmt.format(Date(time))}."
            }
        }
        return "Yaklaşan bir etkinlik göremiyorum."
    }

    // ---------------- Konum ----------------

    private fun currentLocation(context: Context): String {
        if (!hasPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) &&
            !hasPermission(context, android.Manifest.permission.ACCESS_COARSE_LOCATION)
        ) {
            return "Konum izni verilmemiş, bu yüzden göremiyorum."
        }
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = lm.getProviders(true)
        var lastLocation: android.location.Location? = null
        for (provider in providers) {
            val loc = try { lm.getLastKnownLocation(provider) } catch (e: SecurityException) { null }
            if (loc != null && (lastLocation == null || loc.time > lastLocation!!.time)) {
                lastLocation = loc
            }
        }
        val location = lastLocation ?: return "Şu an konumunu belirleyemiyorum, GPS/konum açık mı bir kontrol et."
        return try {
            val geocoder = Geocoder(context, Locale("tr"))
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
            val place = addresses?.firstOrNull()
            if (place != null) {
                val parts = listOfNotNull(place.subLocality, place.locality ?: place.adminArea)
                "Şu an ${parts.joinToString(", ").ifBlank { "bilinmeyen bir yerde" }} civarındasın."
            } else {
                "Konumunu buldum ama adres bilgisine çeviremedim."
            }
        } catch (e: Exception) {
            "Konumunu buldum ama adres bilgisine çeviremedim."
        }
    }

    // ---------------- Fotoğraf ----------------

    private fun lastPhoto(context: Context): String {
        val permission = if (Build.VERSION.SDK_INT >= 33) "android.permission.READ_MEDIA_IMAGES"
                          else android.Manifest.permission.READ_EXTERNAL_STORAGE
        if (!hasPermission(context, permission)) {
            return "Fotoğraf izni verilmemiş, bu yüzden göremiyorum."
        }
        val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DISPLAY_NAME)
        val sort = "${MediaStore.Images.Media.DATE_ADDED} DESC LIMIT 1"

        context.contentResolver.query(uri, projection, null, null, sort)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val dateIdx = cursor.getColumnIndex(MediaStore.Images.Media.DATE_ADDED)
                val dateSec = cursor.getLong(dateIdx)
                val fmt = SimpleDateFormat("d MMMM, HH:mm", Locale("tr"))
                return "En son fotoğrafını ${fmt.format(Date(dateSec * 1000))} tarihinde çekmişsin."
            }
        }
        return "Galeride fotoğraf bulamadım."
    }

    private fun hasPermission(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
}
