package com.heyasistan.app

import android.content.Context

/** Gemini API anahtarını telefonun kendi (uygulamaya özel, gizli) depolama alanında tutar. */
object ApiKeyStore {
    private const val PREFS = "hey_asistan_prefs"
    private const val KEY_GEMINI = "gemini_api_key"

    fun get(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_GEMINI, null)

    fun save(context: Context, apiKey: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_GEMINI, apiKey.trim()).apply()
    }
}
