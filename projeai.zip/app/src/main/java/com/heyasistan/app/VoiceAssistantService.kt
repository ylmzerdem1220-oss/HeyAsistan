package com.heyasistan.app

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat

/**
 * Uygulama kapatılsa/arka plana atılsa bile bildirim çubuğunda "dinliyor"
 * göstergesiyle çalışmaya devam eden servis. "Hey" duyulunca bir sonraki
 * cümleyi CommandRouter'a yollar.
 *
 * NOT: Android, arka planda sürekli mikrofon dinlemeyi kısıtlar; bu yüzden
 * kalıcı bir bildirim (foreground service) zorunludur — kullanıcı bunu
 * bildirim çubuğunda her zaman görür, gizli dinleme yapılmaz.
 */
class VoiceAssistantService : Service() {

    private var speechRecognizer: SpeechRecognizer? = null
    private var awake = false
    private val handler = Handler(Looper.getMainLooper())
    private var restartRunnable: Runnable? = null
    private lateinit var audioManager: AudioManager
    private val savedVolumes = mutableMapOf<Int, Int>()
    private var windowManager: WindowManager? = null
    private var bannerView: View? = null

    companion object {
        const val CHANNEL_ID = "hey_asistan_kanal"
        const val NOTIF_ID = 1001
        const val ACTION_STOP = "com.heyasistan.app.STOP"
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, buildNotification("\"Hey\" bekleniyor..."))
        startListeningLoop()
        return START_STICKY
    }

    private fun startListeningLoop() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNotification("Bu cihazda konuşma tanıma yok")
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle) {
                    val text = results
                        .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull() ?: return
                    onHeard(text)
                }
                override fun onError(error: Int) { scheduleRestart() }
                override fun onEndOfSpeech() { scheduleRestart() }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        startOneListenCycle()
    }

    private fun startOneListenCycle() {
        suppressBeepFully()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            scheduleRestart()
        }
    }

    /**
     * Telefonun "dinlemeye başlıyorum" bip sesini TAMAMEN susturmak için iki
     * yöntemi birlikte kullanıyoruz:
     * 1) Ses odağını (audio focus) kendi üzerimize, "exclusive" modda alıyoruz
     *    — bu, sistemin o an başka bir sesi (bip dahil) çalmasını fiilen engeller.
     * 2) Olası ilgili tüm ses kanallarını (müzik, sistem) sıfıra çekiyoruz.
     * Artık "Hey" öncesi/sonrası ayrımı yapmıyoruz, komple sessiz.
     */
    private fun suppressBeepFully() {
        try {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(
                { /* no-op */ },
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE
            )
        } catch (e: Exception) { }

        for (stream in intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_SYSTEM)) {
            try {
                if (savedVolumes[stream] == null) {
                    savedVolumes[stream] = audioManager.getStreamVolume(stream)
                }
                audioManager.setStreamVolume(stream, 0, 0)
            } catch (e: Exception) { }
        }
    }

    private fun restoreAllVolumes() {
        for ((stream, vol) in savedVolumes) {
            try { audioManager.setStreamVolume(stream, vol, 0) } catch (e: Exception) { }
        }
        savedVolumes.clear()
        try {
            @Suppress("DEPRECATION")
            audioManager.abandonAudioFocus { }
        } catch (e: Exception) { }
    }

    private fun scheduleRestart() {
        restartRunnable?.let { handler.removeCallbacks(it) }
        restartRunnable = Runnable { startOneListenCycle() }
        handler.postDelayed(restartRunnable!!, 300)
    }

    /**
     * Ekranın üst ortasında "Asistan dinliyor" yazan küçük bir banner gösterir.
     * Bu, Android'in sağ üstte otomatik gösterdiği yeşil mikrofon noktasının
     * YERİNE geçmez (o, işletim sisteminin zorunlu gizlilik göstergesidir ve
     * hiçbir uygulama tarafından kaldırılamaz) — buna EK bir görsel bildirimdir.
     * "Diğer uygulamaların üzerinde göster" izni verilmemişse sessizce atlanır.
     */
    private fun showBanner(text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) return
        try {
            if (bannerView == null) {
                val inflated = LayoutInflater.from(this).inflate(R.layout.overlay_banner, null)
                val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    y = 80
                }
                windowManager?.addView(inflated, params)
                bannerView = inflated
            }
            bannerView?.findViewById<TextView>(R.id.overlayBannerText)?.text = text
        } catch (e: Exception) { }
    }

    private fun hideBanner() {
        try {
            bannerView?.let { windowManager?.removeView(it) }
        } catch (e: Exception) { }
        bannerView = null
    }

    private fun onHeard(rawText: String) {
        val norm = CommandRouter.normalize(rawText)
        if (!awake) {
            if (norm.contains("hey")) {
                awake = true
                updateNotification("Dinliyorum — komutunu söyle")
                showBanner("Asistan dinliyor")
                val rest = norm.substringAfter("hey").trim()
                if (rest.length > 2) {
                    runCommand(rest)
                } else {
                    // sadece "hey" denildi, bir sonraki cümleyi komut olarak bekle
                    handler.postDelayed({
                        if (awake) {
                            awake = false
                            updateNotification("\"Hey\" bekleniyor...")
                            hideBanner()
                        }
                    }, 6000)
                }
            }
        } else {
            runCommand(norm)
        }
    }

    private fun runCommand(text: String) {
        awake = false
        val apiKey = ApiKeyStore.get(this)

        if (apiKey.isNullOrBlank()) {
            // Gemini anahtarı girilmemiş: eski kelime-tabanlı (offline) sisteme düş.
            dispatchResult(CommandRouter.handle(this, text))
            return
        }

        updateNotification("Düşünüyor...")
        showBanner("Düşünüyor...")
        GeminiRouter.interpret(apiKey, text) { action ->
            handler.post {
                val result = when (action.type) {
                    "open_app" -> CommandRouter.runAppOpen(this, action.app)
                    "app_search" -> CommandRouter.runAppSearch(this, action.app, action.query)
                    "google_search" -> CommandRouter.runGoogleSearch(this, action.query)
                    "call_contact" -> CommandRouter.runCall(this, action.contactName)
                    else -> CommandRouter.Result.NotUnderstood
                }
                // Gemini "unknown" dediyse ya da hiçbir eylem üretemediyse,
                // son çare olarak eski kelime-tabanlı sistemi dene.
                val finalResult = if (result == CommandRouter.Result.NotUnderstood) {
                    CommandRouter.handle(this, text)
                } else result
                dispatchResult(finalResult)
            }
        }
    }

    private fun dispatchResult(result: CommandRouter.Result) {
        hideBanner()
        when (result) {
            is CommandRouter.Result.OpenedApp -> updateNotification("${result.label} açıldı")
            is CommandRouter.Result.OpenedAppSearch -> updateNotification("${result.label}: \"${result.query}\" arandı")
            is CommandRouter.Result.OpenedSearch -> updateNotification("Google'da arandı: ${result.query}")
            is CommandRouter.Result.Calling -> updateNotification("${result.name} aranıyor")
            is CommandRouter.Result.ContactNotFound -> updateNotification("${result.name} rehberde bulunamadı")
            CommandRouter.Result.NotUnderstood -> updateNotification("Anlaşılamadı — \"Hey\" bekleniyor")
        }
        handler.postDelayed({ updateNotification("\"Hey\" bekleniyor...") }, 2500)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Hey Asistan Dinleme",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Arka planda \"Hey\" kelimesini dinlerken gösterilir" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = Intent(this, VoiceAssistantService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Hey Asistan")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(0, "Durdur", stopPending)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        restartRunnable?.let { handler.removeCallbacks(it) }
        restoreAllVolumes()
        hideBanner()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
