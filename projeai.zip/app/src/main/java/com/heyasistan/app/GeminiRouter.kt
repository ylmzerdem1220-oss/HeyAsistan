package com.heyasistan.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Söylenen cümleyi Gemini API'ye gönderip ne yapmak istediğini (uygulama açma,
 * uygulama içi arama, Google arama, kişi arama) yorumlatan sınıf.
 * Sabit kelime kalıplarına bağlı değildir — "kanka gibi" doğal cümleleri de
 * anlayabilir, çünkü yorumlamayı gerçek bir dil modeli yapıyor.
 */
object GeminiRouter {

    data class ParsedAction(
        val type: String, // open_app | app_search | google_search | call_contact | unknown
        val app: String? = null,
        val query: String? = null,
        val contactName: String? = null
    )

    private const val ENDPOINT =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"

    /**
     * Ağ isteğini arka planda (kendi thread'inde) yapar; sonucu onResult ile döner.
     * Bir hata/timeout olursa type="unknown" ile döner, uygulama çökmez.
     */
    fun interpret(apiKey: String, spokenText: String, onResult: (ParsedAction) -> Unit) {
        Thread {
            val action = try {
                callGemini(apiKey, spokenText)
            } catch (e: Exception) {
                ParsedAction("unknown")
            }
            onResult(action)
        }.start()
    }

    private fun callGemini(apiKey: String, text: String): ParsedAction {
        val body = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().put(
                    JSONObject().put("text", buildPrompt(text))
                ))
            ))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0)
                put("responseMimeType", "application/json")
            })
        }

        val conn = URL("$ENDPOINT?key=$apiKey").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.doOutput = true
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val responseText = stream?.bufferedReader()?.use { it.readText() } ?: ""
        conn.disconnect()

        if (code !in 200..299) return ParsedAction("unknown")

        val json = JSONObject(responseText)
        val candidates = json.optJSONArray("candidates") ?: return ParsedAction("unknown")
        if (candidates.length() == 0) return ParsedAction("unknown")

        val parts = candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        val rawText = parts.getJSONObject(0).getString("text")

        val cleaned = rawText.trim()
            .removePrefix("```json").removePrefix("```")
            .removeSuffix("```").trim()

        val parsed = JSONObject(cleaned)
        return ParsedAction(
            type = parsed.optString("type", "unknown"),
            app = parsed.optStringOrNull("app"),
            query = parsed.optStringOrNull("query"),
            contactName = parsed.optStringOrNull("contact_name")
        )
    }

    private fun JSONObject.optStringOrNull(key: String): String? {
        if (!has(key) || isNull(key)) return null
        val v = optString(key)
        return if (v.isBlank() || v.equals("null", ignoreCase = true)) null else v
    }

    private fun buildPrompt(text: String): String = """
        Sen bir Android telefonun sesli asistanısın. Kullanıcının Türkçe söylediği
        komutu yorumla ve SADECE aşağıdaki JSON şemasında cevap ver, başka hiçbir
        açıklama, yorum ya da kod bloğu işareti ekleme:

        {"type":"open_app|app_search|google_search|call_contact|unknown","app":null_veya_uygulama_adi,"query":null_veya_aranacak_metin,"contact_name":null_veya_kisi_ismi}

        Alan açıklamaları:
        - app: küçük harf uygulama adı (youtube, instagram, whatsapp, spotify, twitter,
          netflix, gmail, chrome, harita, ayarlar, kamera, galeri, telegram, tiktok,
          veya kullanıcının bahsettiği başka gerçek bir uygulama adı).
        - query: uygulama içinde ya da Google'da aratılacak/gösterilecek metin.
        - contact_name: telefonla aranacak kişinin ismi.

        Kurallar:
        - Kullanıcı sadece bir uygulamayı açmak istiyorsa: type=open_app, app doldur.
        - Kullanıcı bir uygulama içinde bir şey/kanal/şarkı/video aratmak istiyorsa
          (örn. "youtube'de X kanalını aç", "spotify'da Y çal"): type=app_search,
          app ve query doldur.
        - Kullanıcı belirli bir uygulama belirtmeden bir şeyi Google'da/internette
          aratmak istiyorsa: type=google_search, query doldur.
        - Kullanıcı telefonla birini aramak istiyorsa: type=call_contact,
          contact_name doldur.
        - Hiçbirine uymuyorsa ya da anlamlı bir komut değilse: type=unknown.
        - Asla JSON dışında hiçbir karakter yazma.

        Kullanıcının cümlesi: "$text"
    """.trimIndent()
}
