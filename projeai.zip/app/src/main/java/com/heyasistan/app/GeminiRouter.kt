package com.heyasistan.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Söylenen cümleyi Gemini API'ye gönderip ne yapmak istediğini (uygulama açma,
 * uygulama içi arama, Google arama, kişi arama) yorumlatan sınıf.
 * Sabit kelime kalıplarına bağlı değildir — "kanka gibi" doğal cümleleri de
 * anlayabilir, çünkü yorumlamayı gerçek bir dil modeli yapıyor.
 */
object GeminiRouter {

    data class ParsedAction(
        val type: String, // open_app | app_search | google_search | call_contact | question | phone_info | device_control | unknown
        val app: String? = null,
        val query: String? = null,
        val contactName: String? = null,
        val infoKind: String? = null,
        val controlKind: String? = null
    )

    private const val ENDPOINT =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"

    /**
     * Ağ isteğini arka planda (kendi thread'inde) yapar; sonucu onResult ile döner.
     * Bir hata/timeout olursa type="unknown" ile döner, uygulama çökmez.
     */
    fun interpret(apiKey: String, spokenText: String, onResult: (ParsedAction) -> Unit) {
        Thread {
            val action = try {
                callGemini(apiKey, spokenText)
            } catch (e: Exception) {
                ParsedAction("unknown")
            }
            onResult(action)
        }.start()
    }

    private fun callGemini(apiKey: String, text: String): ParsedAction {
        val body = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().put(
                    JSONObject().put("text", buildPrompt(text))
                ))
            ))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0)
                put("responseMimeType", "application/json")
            })
        }

        val conn = URL("$ENDPOINT?key=$apiKey").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.doOutput = true
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val responseText = stream?.bufferedReader()?.use { it.readText() } ?: ""
        conn.disconnect()

        if (code !in 200..299) return ParsedAction("unknown")

        val json = JSONObject(responseText)
        val candidates = json.optJSONArray("candidates") ?: return ParsedAction("unknown")
        if (candidates.length() == 0) return ParsedAction("unknown")

        val parts = candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        val rawText = parts.getJSONObject(0).getString("text")

        val cleaned = rawText.trim()
            .removePrefix("```json").removePrefix("```")
            .removeSuffix("```").trim()

        val parsed = JSONObject(cleaned)
        return ParsedAction(
            type = parsed.optString("type", "unknown"),
            app = parsed.optStringOrNull("app"),
            query = parsed.optStringOrNull("query"),
            contactName = parsed.optStringOrNull("contact_name"),
            infoKind = parsed.optStringOrNull("info_kind"),
            controlKind = parsed.optStringOrNull("control_kind")
        )
    }

    private fun JSONObject.optStringOrNull(key: String): String? {
        if (!has(key) || isNull(key)) return null
        val v = optString(key)
        return if (v.isBlank() || v.equals("null", ignoreCase = true)) null else v
    }

    private fun buildPrompt(text: String): String = """
        Sen bir Android telefonun sesli asistanısın. Kullanıcının Türkçe söylediği
        komutu yorumla ve SADECE aşağıdaki JSON şemasında cevap ver, başka hiçbir
        açıklama, yorum ya da kod bloğu işareti ekleme:

        {"type":"open_app|app_search|google_search|call_contact|question|phone_info|device_control|unknown","app":null_veya_uygulama_adi,"query":null_veya_aranacak_metin,"contact_name":null_veya_kisi_ismi,"info_kind":null_veya_bilgi_turu,"control_kind":null_veya_kontrol_turu}

        Alan açıklamaları:
        - app: küçük harf uygulama adı (youtube, instagram, whatsapp, spotify, twitter,
          netflix, gmail, chrome, harita, ayarlar, kamera, galeri, telegram, tiktok,
          veya kullanıcının bahsettiği başka gerçek bir uygulama adı).
        - query: uygulama içinde ya da Google'da aratılacak/gösterilecek metin;
          SMS gönderirken mesaj metni; alarm kurarken saat (HH:MM formatında,
          24 saatlik, örn "07:30"); zamanlayıcı kurarken sadece dakika sayısı
          (örn "10").
        - contact_name: telefonla aranacak/sorulan/SMS atılacak kişinin ismi.
        - info_kind: type=phone_info olduğunda, şu değerlerden biri:
          "last_sms_code" (en son gelen SMS doğrulama kodu),
          "last_sent_message" (en son kime mesaj/SMS atıldığı),
          "last_received_message" (en son kimden mesaj/SMS geldiği),
          "last_call" (en son kiminle konuşulduğu/arandığı),
          "call_duration" (belirli biriyle ya da genel olarak kaç dakika konuşulduğu),
          "battery_status" (pil yüzdesi/şarj durumu),
          "connectivity_status" (internet/Wi-Fi/mobil veri bağlı mı),
          "storage_status" (depolama alanı ne kadar dolu/boş),
          "installed_apps_count" (kaç uygulama yüklü),
          "next_alarm" (sıradaki alarm ne zaman),
          "calendar_today" (bugün takvimde ne var),
          "calendar_tomorrow" (yarın takvimde ne var),
          "calendar_next" (bir sonraki/yaklaşan takvim etkinliği),
          "current_location" (şu an nerede olduğu),
          "last_photo" (en son ne zaman fotoğraf çekildiği),
          "app_notification" (belirli bir uygulamadan -whatsapp, instagram,
          gmail vb.- en son ne bildirim geldiği; bu durumda app alanına o
          uygulamanın adını yaz).
        - control_kind: type=device_control olduğunda, şu değerlerden biri:
          "flashlight_on", "flashlight_off" (fener aç/kapat),
          "volume_up", "volume_down", "mute" (ses aç/kıs/kapat),
          "brightness_up", "brightness_down" (ekran parlaklığı aç/kıs),
          "play_media", "pause_media", "next_media", "previous_media"
          (müziği çal/durdur/sonraki/önceki şarkı),
          "whats_playing" (şu an ne çaldığı),
          "send_sms" (birine SMS gönderme; contact_name ve query -mesaj
          metni- doldurulmalı),
          "send_whatsapp" (kullanıcı açıkça "whatsapp" derse birine WhatsApp'tan
          mesaj gönderme; contact_name ve query -mesaj metni- doldurulmalı;
          kullanıcı "whatsapp" demeden sadece "mesaj gönder"/"SMS at" derse
          bunun yerine send_sms kullan),
          "set_alarm" (alarm kurma; query'e saat HH:MM formatında yaz),
          "set_timer" (zamanlayıcı/geri sayım kurma; query'e sadece dakika
          sayısı yaz),
          "open_wifi_settings", "open_bluetooth_settings" (ilgili ayarlar
          ekranını açma).

        Kurallar:
        - Kullanıcı sadece bir uygulamayı açmak istiyorsa: type=open_app, app doldur.
        - Kullanıcı bir uygulama içinde bir şey/kanal/şarkı/video aratmak istiyorsa
          (örn. "youtube'de X kanalını aç", "spotify'da Y çal"): type=app_search,
          app ve query doldur.
        - Kullanıcı belirli bir uygulama belirtmeden bir şeyi Google'da/internette
          aratmak istiyorsa (bir web sayfası/sonuç listesi açmasını istiyorsa):
          type=google_search, query doldur.
        - Kullanıcı telefonla birini ARAMAK (çağrı başlatmak) istiyorsa: type=call_contact,
          contact_name doldur.
        - Kullanıcı telefonun kendi SMS/arama geçmişi, pil, internet, depolama,
          takvim, konum, fotoğraf, alarm ya da BİR UYGULAMADAN GELEN BİLDİRİM
          (örn. "WhatsApp'tan ne geldi", "gmail'e mail gelmiş mi") ile ilgili
          bir şey soruyorsa: type=phone_info, info_kind'i yukarıdaki listeden
          uygun olanla doldur; kişiyle ilgiliyse contact_name'e, uygulamayla
          ilgiliyse (app_notification) app alanına yaz.
        - Kullanıcı fener, ses, parlaklık, müzik oynatma, SMS gönderme, alarm/
          zamanlayıcı kurma ya da WiFi/Bluetooth ayarlarını açma gibi bir
          CİHAZ KONTROLÜ istiyorsa: type=device_control, control_kind'i
          yukarıdaki listeden uygun olanla doldur.
        - Kullanıcı genel bir bilgi/sohbet sorusu soruyorsa (örn. "Türkiye'nin
          başkenti neresi", "yarın hava nasıl olacak", telefonun kendi verisiyle
          ilgisiz genel sorular): type=question.
        - Hiçbirine uymuyorsa ya da anlamlı bir komut değilse: type=unknown.
        - Asla JSON dışında hiçbir karakter yazma.

        Kullanıcının cümlesi: "$text"
    """.trimIndent()

    /**
     * Bir soruyu Gemini'ye, Google Arama ile "gerçek zamanlı bilgiye bakarak"
     * (grounding) cevaplatır. Sonuç, sesli okunmaya uygun kısa bir Türkçe
     * cümle/cümleler olarak döner.
     */
    fun answerQuestion(apiKey: String, question: String, onResult: (String) -> Unit) {
        Thread {
            val answer = try {
                fetchGroundedAnswer(apiKey, question)
            } catch (e: Exception) {
                "Şu an cevap veremedim, internet bağlantını kontrol eder misin?"
            }
            onResult(answer)
        }.start()
    }

    private fun fetchGroundedAnswer(apiKey: String, question: String): String {
        val prompt = """
            Sen sesli bir telefon asistanısın. Kullanıcı şunu sordu: "$question"
            Gerekiyorsa güncel bilgiye Google araması ile bak, sonra SESLİ olarak
            okunacak şekilde, doğal, kısa (en fazla 2-3 cümle), sade bir Türkçe
            cevap ver. Kaynak linki, markdown, yıldız işareti gibi şeyler kullanma,
            sadece düz konuşma dili kullan.
        """.trimIndent()

        val body = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().put(
                    JSONObject().put("text", prompt)
                ))
            ))
            put("tools", JSONArray().put(
                JSONObject().put("google_search", JSONObject())
            ))
        }

        val conn = URL("$ENDPOINT?key=$apiKey").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.doOutput = true
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val responseText = stream?.bufferedReader()?.use { it.readText() } ?: ""
        conn.disconnect()

        if (code !in 200..299) return "Şu an cevap alamadım."

        val json = JSONObject(responseText)
        val candidates = json.optJSONArray("candidates") ?: return "Şu an cevap alamadım."
        if (candidates.length() == 0) return "Şu an cevap alamadım."

        val parts = candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        // Grounding kullanıldığında bazen birden fazla "parts" gelebilir, hepsindeki
        // metni birleştiriyoruz.
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val part = parts.getJSONObject(i)
            if (part.has("text")) sb.append(part.getString("text"))
        }
        val result = sb.toString().trim()
        return result.ifBlank { "Bunun için net bir cevap bulamadım." }
    }
}
