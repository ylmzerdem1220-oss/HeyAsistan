package com.heyasistan.app

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract

/**
 * Söylenen metni yorumlayıp gerçek bir eylem (uygulama açma, arama yapma,
 * Google'da arama) üreten sınıf. Hem MainActivity (ön planda) hem de
 * VoiceAssistantService (arka planda) bunu kullanır.
 */
object CommandRouter {

    sealed class Result {
        data class OpenedApp(val label: String) : Result()
        data class OpenedSearch(val query: String) : Result()
        data class Calling(val name: String, val number: String) : Result()
        data class ContactNotFound(val name: String) : Result()
        object NotUnderstood : Result()
    }

    private val APP_ALIASES = mapOf(
        "youtube" to "com.google.android.youtube",
        "instagram" to "com.instagram.android",
        "whatsapp" to "com.whatsapp",
        "twitter" to "com.twitter.android",
        "x" to "com.twitter.android",
        "spotify" to "com.spotify.music",
        "gmail" to "com.google.android.gm",
        "netflix" to "com.netflix.mediaclient",
        "harita" to "com.google.android.apps.maps",
        "haritalar" to "com.google.android.apps.maps",
        "chrome" to "com.android.chrome",
        "ayarlar" to "com.android.settings",
        "kamera" to "com.android.camera",
        "galeri" to "com.google.android.apps.photos",
        "telegram" to "org.telegram.messenger",
        "tiktok" to "com.zhiliaoapp.musically"
    )

    fun normalize(s: String): String =
        s.lowercase()
            .replace("İ", "i").replace("I", "ı")
            .replace(Regex("['’]"), "")
            .trim()

    /**
     * "hey" ten sonra söylenen komutu işler ve uygun eylemi çalıştırır.
     */
    fun handle(context: Context, rawText: String): Result {
        val text = normalize(rawText)

        // 1) "google'da X ara" / "google de ara X"
        val googlePattern1 = Regex("google\\s*(da|de|dan|den)?\\s*(.+?)\\s*ara$")
        val googlePattern2 = Regex("^google\\s*(da|de)?\\s*ara\\s*(.+)$")
        val gm1 = googlePattern1.find(text)
        val gm2 = googlePattern2.find(text)
        val query = gm1?.groupValues?.get(2) ?: gm2?.groupValues?.get(2)
        if (!query.isNullOrBlank()) {
            val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query.trim()))
            val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return Result.OpenedSearch(query.trim())
        }

        // 2) Kişi arama: "annemi ara" / "ara annem"
        Regex("(.+?)\\w*\\s*(i|ı|u|ü|yi|yı)?\\s*ara$").find(text)?.let { m ->
            val candidateName = m.groupValues[1].trim()
            if (candidateName.isNotBlank() && !APP_ALIASES.keys.any { candidateName.contains(it) }) {
                val number = lookupContactNumber(context, candidateName)
                if (number != null) {
                    val call = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(call)
                    return Result.Calling(candidateName, number)
                } else {
                    return Result.ContactNotFound(candidateName)
                }
            }
        }
        if (text.startsWith("ara ")) {
            val name = text.removePrefix("ara ").trim()
            val number = lookupContactNumber(context, name)
            if (number != null) {
                val call = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(call)
                return Result.Calling(name, number)
            }
            return Result.ContactNotFound(name)
        }

        // 3) Uygulama açma: "X aç" / "aç X"
        for ((alias, pkg) in APP_ALIASES) {
            val p1 = Regex("$alias\\w*\\s*(i|ı|u|ü|yi|yı)?\\s*aç")
            val p2 = Regex("aç\\s*$alias")
            if (p1.containsMatchIn(text) || p2.containsMatchIn(text)) {
                if (launchByPackage(context, pkg)) return Result.OpenedApp(alias)
                // paket telefonda kurulu değilse, yüklü uygulamalar arasında isimden ara
                if (launchByLabel(context, alias)) return Result.OpenedApp(alias)
                return Result.NotUnderstood
            }
        }

        // 4) Bilinmeyen ama "aç" içeren komut: yüklü uygulamalar arasında isimle eşleştirmeyi dene
        Regex("(.+?)\\w*\\s*(i|ı|u|ü|yi|yı)?\\s*aç$").find(text)?.let { m ->
            val appGuess = m.groupValues[1].trim()
            if (appGuess.isNotBlank() && launchByLabel(context, appGuess)) {
                return Result.OpenedApp(appGuess)
            }
        }

        return Result.NotUnderstood
    }

    private fun launchByPackage(context: Context, packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    /** Paket adını bilmediğimiz uygulamaları görünen isimlerinden bulup açar. */
    private fun launchByLabel(context: Context, spokenName: String): Boolean {
        val pm = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcherIntent, 0)
        val target = apps.firstOrNull { info ->
            val label = info.loadLabel(pm).toString().lowercase()
            label.contains(spokenName) || spokenName.contains(label)
        } ?: return false

        val launch = pm.getLaunchIntentForPackage(target.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return true
    }

    /** READ_CONTACTS izniyle rehberden isme göre telefon numarası bulur. */
    private fun lookupContactNumber(context: Context, spokenName: String): String? {
        val resolver = context.contentResolver
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        resolver.query(uri, projection, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (cursor.moveToNext()) {
                val name = cursor.getString(nameIdx)?.lowercase() ?: continue
                if (name.contains(spokenName) || spokenName.contains(name)) {
                    return cursor.getString(numberIdx)
                }
            }
        }
        return null
    }
}
