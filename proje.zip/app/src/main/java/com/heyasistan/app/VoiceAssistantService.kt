package com.heyasistan.app

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat

/**
 * Uygulama kapatılsa/arka plana atılsa bile bildirim çubuğunda "dinliyor"
 * göstergesiyle çalışmaya devam eden servis. "Hey" duyulunca bir sonraki
 * cümleyi CommandRouter'a yollar.
 *
 * NOT: Android, arka planda sürekli mikrofon dinlemeyi kısıtlar; bu yüzden
 * kalıcı bir bildirim (foreground service) zorunludur — kullanıcı bunu
 * bildirim çubuğunda her zaman görür, gizli dinleme yapılmaz.
 */
class VoiceAssistantService : Service() {

    private var speechRecognizer: SpeechRecognizer? = null
    private var awake = false
    private val handler = Handler(Looper.getMainLooper())
    private var restartRunnable: Runnable? = null

    companion object {
        const val CHANNEL_ID = "hey_asistan_kanal"
        const val NOTIF_ID = 1001
        const val ACTION_STOP = "com.heyasistan.app.STOP"
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, buildNotification("\"Hey\" bekleniyor..."))
        startListeningLoop()
        return START_STICKY
    }

    private fun startListeningLoop() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNotification("Bu cihazda konuşma tanıma yok")
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle) {
                    val text = results
                        .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull() ?: return
                    onHeard(text)
                }
                override fun onError(error: Int) { scheduleRestart() }
                override fun onEndOfSpeech() { scheduleRestart() }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        startOneListenCycle()
    }

    private fun startOneListenCycle() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            scheduleRestart()
        }
    }

    private fun scheduleRestart() {
        restartRunnable?.let { handler.removeCallbacks(it) }
        restartRunnable = Runnable { startOneListenCycle() }
        handler.postDelayed(restartRunnable!!, 300)
    }

    private fun onHeard(rawText: String) {
        val norm = CommandRouter.normalize(rawText)
        if (!awake) {
            if (norm.contains("hey")) {
                awake = true
                updateNotification("Dinliyorum — komutunu söyle")
                val rest = norm.substringAfter("hey").trim()
                if (rest.length > 2) {
                    runCommand(rest)
                } else {
                    // sadece "hey" denildi, bir sonraki cümleyi komut olarak bekle
                    handler.postDelayed({
                        if (awake) {
                            awake = false
                            updateNotification("\"Hey\" bekleniyor...")
                        }
                    }, 6000)
                }
            }
        } else {
            runCommand(norm)
        }
    }

    private fun runCommand(text: String) {
        awake = false
        when (val result = CommandRouter.handle(this, text)) {
            is CommandRouter.Result.OpenedApp -> updateNotification("${result.label} açıldı")
            is CommandRouter.Result.OpenedSearch -> updateNotification("Google'da arandı: ${result.query}")
            is CommandRouter.Result.Calling -> updateNotification("${result.name} aranıyor")
            is CommandRouter.Result.ContactNotFound -> updateNotification("${result.name} rehberde bulunamadı")
            CommandRouter.Result.NotUnderstood -> updateNotification("Anlaşılamadı — \"Hey\" bekleniyor")
        }
        handler.postDelayed({ updateNotification("\"Hey\" bekleniyor...") }, 2500)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Hey Asistan Dinleme",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Arka planda \"Hey\" kelimesini dinlerken gösterilir" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = Intent(this, VoiceAssistantService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Hey Asistan")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(0, "Durdur", stopPending)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        restartRunnable?.let { handler.removeCallbacks(it) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
